-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  sam. 13 juin 2020 à 20:07
-- Version du serveur :  8.0.17
-- Version de PHP :  7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `perfect cup`
--

-- --------------------------------------------------------

--
-- Structure de la table `memebers`
--

CREATE TABLE `memebers` (
  `id` int(11) NOT NULL,
  `fname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `memebers`
--

INSERT INTO `memebers` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(1, 'oussama', 'chajii', 'chajiioussama254@gmail.com', '$2y$12$pJWxLzwyVaqCdV4muyoWhO5YBSXXQyDE1ed37xoBN7sIXhMfm3VKq'),
(2, 'oussama', 'chajii', 'chajiioussama@gmail.com', '$2y$12$sF//E4fT3nhBR5oyB0ezLe0FEYPq1HuQunJyljWQ28QyL3a05Tr.O'),
(3, 'oussama', 'chajii', 'chajiioa254@gmail.com', '$2y$12$Wn0qPDptsPnnJqKosdIf3esBFVLY7I50nVXKr58L4fzf89qwUz2Xy');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `memebers`
--
ALTER TABLE `memebers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `memebers`
--
ALTER TABLE `memebers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
